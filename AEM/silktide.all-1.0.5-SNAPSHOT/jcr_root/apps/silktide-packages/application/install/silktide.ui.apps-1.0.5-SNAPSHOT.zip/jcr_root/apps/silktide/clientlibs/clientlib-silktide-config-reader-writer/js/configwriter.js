$(window).load(function() {
    $('.silktide-config-form .coral3-Button--secondary').click(function(e) {
       e.preventDefault();
       e.stopPropagation();
       location.href = location.origin;
    });

    $('.silktide-config-writer').click(function(e) {
        e.preventDefault();
        e.stopPropagation();
        var endpointUrl = $(".silktide-config-form input[name*='endpointUrl']").val();
        var apiKey = $(".silktide-config-form input[name*='apiKey']").val();
        var formData = {endpointUrl: endpointUrl,apiKey: apiKey};
        $.ajax({
            url : "/bin/silktide/writeconfig",
            type: "POST",
            data : formData,
            success: function(data, textStatus, jqXHR) {
              $("#successAlert").remove();
              var dialog = new Coral.Dialog().set({
                id: 'successAlert',
                header: {
                  innerHTML: 'Success'
                },
                content: {
                  innerHTML: 'Silktide is ready to use now'
                },
                footer: {
                  innerHTML: '<button onclick="location.href = location.origin" is="coral-button" variant="primary" coral-close>Ok</button>'
                },
                variant: "success"
              });
              document.body.appendChild(dialog);
              var dialog = document.querySelector('#successAlert');
              dialog.show();
            },
            error: function (jqXHR, textStatus, errorThrown) {
              $("#errorAlert").remove();
              var dialog = new Coral.Dialog().set({
                id: 'successAlert',
                header: {
                  innerHTML: 'Error'
                },
                content: {
                  innerHTML: 'Unable to save changes. Please try again later'
                },
                footer: {
                  innerHTML: '<button onclick="location.reload()" is="coral-button" variant="primary" coral-close>Ok</button>'
                },
                variant: "error"
              });
              document.body.appendChild(dialog);
              var dialog = document.querySelector('#errorAlert');
              dialog.show();
            }
        });
    });
});
