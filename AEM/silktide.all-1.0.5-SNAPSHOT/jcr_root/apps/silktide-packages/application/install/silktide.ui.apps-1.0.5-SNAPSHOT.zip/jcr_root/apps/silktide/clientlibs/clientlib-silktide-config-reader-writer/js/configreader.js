$(window).load(function() {
    if($(".silktide-config-form").length > 0) {
        $.ajax({
            url : "/bin/silktide/readconfig",
            type: "GET",
            success: function(data, textStatus, jqXHR) {
                var jsonResponse = JSON.parse(data);
                var endpointUrl = jsonResponse.endpointUrl;
                var apiKey = jsonResponse.apiKey;
                $(".silktide-config-form input[name*='endpointUrl']").val(endpointUrl);
                $(".silktide-config-form input[name*='apiKey']").val(apiKey);
            },
            error: function (jqXHR, textStatus, errorThrown){
                console.log("unable to fetch silktide configs");
            }
        });
    }
});
