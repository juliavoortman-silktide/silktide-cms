$(document).ready(function(e) {
    $.getScript('https://cms.silktide.com/toolbar/silktide-toolbar.js'); // for production
    // $.getScript('http://localhost:8000/silktide-toolbar.js'); // for testing locallyq

    function triggerIframePopup(endpointUrl, apiKey) {
        if (window.SilktideToolbar) {
            SilktideToolbar.init({
                apiUrl: endpointUrl,
                accessToken: apiKey,

                // AEM hosts the website in an iframe. If we pass this iframe window directly to kirby,
                // We don't have to manually cleanup any of the AEM dom pollution, which is honestly great.
                // Thank you AEM for actually making a decent and coherent decision.
                kirbyWindow: () => document.getElementById('ContentFrame')?.contentWindow,

                // This enables kirby to send local files over (where our backend wouldn't be able to request them)
                forceExtractResources: true
            });
            if (SilktideToolbar.runQuickScan) {
                SilktideToolbar.runQuickScan();
            } else {
                SilktideToolbar.toggleOpen();
            }
        } else {
            console.log("unable to load toolbar");
        }
    }

    function setTitle(status) {
        $(".silktide-button").attr("title", status);
    }

    function setDisabledClass() {
        $(".silktide-button").addClass('silktide-disabled');
    }

    function isSilktideEnabled() {
        return !$('.silktide-button').hasClass('silktide-disabled');
    }

    $('.silktide-button').click(function(e) {
        e.preventDefault();
        e.stopPropagation();
        if(isSilktideEnabled()) {
            $.ajax({
                url : "/bin/silktide/readconfig",
                type: "GET",
                success: function(data, textStatus, jqXHR) {
                    var jsonResponse = JSON.parse(data);
                    var endpointUrl = jsonResponse.endpointUrl;
                    var apiKey = jsonResponse.apiKey;
                    triggerIframePopup(endpointUrl, apiKey);
                },
                error: function (jqXHR, textStatus, errorThrown){
                    console.error("unable to fetch silktide configs");
                }
            });
        }
    });
    if($(".silktide-button").length > 0) {
        var pagePath = window.location.pathname.split('.html')[1];
        $.ajax({
            url : pagePath + "/jcr:content.silktidevalidator.json?pagePath="+pagePath,
            type: "GET",
            success: function(data, textStatus, jqXHR) {
                if(data) {
                    $(".silktide-button").removeAttr('disabled');
                    var status = data.status;
                    if(status === 'Silktide Enabled') {
                        setTitle(status);
                    } else if(status === 'Silktide Disabled') {
                        setTitle(status);
                        setDisabledClass();
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown){
                console.log("unable to validate silktide integration");
            }
        });
    }

});
